---
title: Building fill down
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
