---
title: Border right
categories:
  - UI and keyboard
tags:
  - borders
---
