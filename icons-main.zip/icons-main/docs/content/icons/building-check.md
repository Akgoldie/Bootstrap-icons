---
title: Building check
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
