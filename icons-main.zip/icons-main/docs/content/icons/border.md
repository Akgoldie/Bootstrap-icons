---
title: Border
categories:
  - UI and keyboard
tags:
  - borders
---
